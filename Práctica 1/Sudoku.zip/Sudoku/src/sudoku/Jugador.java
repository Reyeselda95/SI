/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package sudoku;

/**
 *
 * @author Sistemas Inteligentes
 */
public class Jugador{

    /**
     * Se llama desde la clase Interfaz para ejecutar BC.
     * Al final de la función la solución del tablero se debe encontrar en tablero
     * @param tablero
     * @return
     */
    public boolean ejecutarBC(Tablero tablero)
    {
        return true;
    }
}

  